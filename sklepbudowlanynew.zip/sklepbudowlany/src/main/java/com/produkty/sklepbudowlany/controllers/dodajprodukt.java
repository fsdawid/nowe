package com.produkty.sklepbudowlany.controllers;

import com.produkty.sklepbudowlany.model.Produkt;
import com.produkty.sklepbudowlany.repositories.ProduktRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class dodajprodukt {

    private ProduktRepository produktRepository;


    public dodajprodukt(ProduktRepository produktRepository) {
        this.produktRepository = produktRepository;
    }



    @RequestMapping("dodajprodukt")
    public String showNewProductPage(Model model) {
        Produkt produkt = new Produkt();
        model.addAttribute("dodajprodukt", produkt);

        return "dodajprodukt";
    }
    @RequestMapping(value = "/save1", method = RequestMethod.POST)
    public String saveprodukt(@ModelAttribute("produkt") Produkt produkt   ) {
        produktRepository.save(produkt);


        return "redirect:/produkt";}



}
