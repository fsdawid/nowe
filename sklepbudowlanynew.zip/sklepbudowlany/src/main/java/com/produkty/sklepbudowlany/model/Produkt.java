package com.produkty.sklepbudowlany.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;


public class Produkt {
    @Id
    @GeneratedValue

    private Long Id;
    private String Nazwa;

    public Produkt() {
    }

    public Produkt(String nazwa) {
        Nazwa = nazwa;
    }

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public String getNazwa() {
        return Nazwa;
    }

    public void setNazwa(String nazwa) {
        Nazwa = nazwa;
    }

    @Override
    public String toString() {
        return "Produkt{" +
                "Id=" + Id +
                ", Nazwa='" + Nazwa + '\'' +
                '}';
    }
}
