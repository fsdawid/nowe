package com.produkty.sklepbudowlany.controllers;

import com.produkty.sklepbudowlany.model.Nazwa;
import com.produkty.sklepbudowlany.repositories.NazwaRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class dodajnazwa {

    private NazwaRepository nazwaRepository;


    public dodajnazwa(NazwaRepository nazwaRepository) {
        this.nazwaRepository = nazwaRepository;
    }



    @RequestMapping("dodajnazwa")
    public String showNewProductPage(Model model) {
        Nazwa nazwa = new Nazwa();
        model.addAttribute("dodajnazwa", nazwa);

        return "dodajnazwa";
    }
    @RequestMapping(value = "/save2", method = RequestMethod.POST)
    public String savenazwa(@ModelAttribute("nazwa") Nazwa nazwa    ) {
        nazwaRepository.save(nazwa);


        return "redirect:/nazwa";}



}
