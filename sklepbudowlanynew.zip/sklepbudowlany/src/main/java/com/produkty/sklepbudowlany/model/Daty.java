package com.produkty.sklepbudowlany.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import java.util.HashSet;
import java.util.Set;
@Entity
public class Daty {
    @Id
    @GeneratedValue
    private Long Id;
    private String Dataprodukcji;
    private String Datawaznosci;
    @ManyToMany (mappedBy = "Daty")
    private Set<Dodatkowe> Dodatkowe= new HashSet<>();

    public Daty() {
    }

    public Daty(String dataprodukcji, String datawaznosci) {
        Dataprodukcji = dataprodukcji;
        Datawaznosci = datawaznosci;
    }

    public Daty(Long id, String dataprodukcji, String datawaznosci, Set<com.produkty.sklepbudowlany.model.Dodatkowe> dodatkowe) {
        Id = id;
        Dataprodukcji = dataprodukcji;
        Datawaznosci = datawaznosci;
        Dodatkowe = dodatkowe;
    }

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public String getDataprodukcji() {
        return Dataprodukcji;
    }

    public void setDataprodukcji(String dataprodukcji) {
        Dataprodukcji = dataprodukcji;
    }

    public String getDatawaznosci() {
        return Datawaznosci;
    }

    public void setDatawaznosci(String datawaznosci) {
        Datawaznosci = datawaznosci;
    }

    public Set<com.produkty.sklepbudowlany.model.Dodatkowe> getDodatkowe() {
        return Dodatkowe;
    }

    public void setDodatkowe(Set<com.produkty.sklepbudowlany.model.Dodatkowe> dodatkowe) {
        Dodatkowe = dodatkowe;
    }

    @Override
    public String toString() {
        return "Daty{" +
                "Id=" + Id +
                ", Dataprodukcji='" + Dataprodukcji + '\'' +
                ", Datawaznosci='" + Datawaznosci + '\'' +
                ", Dodatkowe=" + Dodatkowe +
                '}';
    }
}

