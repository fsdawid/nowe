package com.produkty.sklepbudowlany.repositories;

import com.produkty.sklepbudowlany.model.Daty;
import org.springframework.data.repository.CrudRepository;

public interface DatyRepository extends CrudRepository<Daty,Long> {
}
