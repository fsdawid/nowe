package com.produkty.sklepbudowlany.controllers;

import com.produkty.sklepbudowlany.repositories.DatyRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class DatyController {
    private DatyRepository datyRepository;
    public DatyController(DatyRepository datyRepository) {
        this.datyRepository = datyRepository;
    }

    @RequestMapping("daty")
    public String getdaty(Model model) {


        model.addAttribute("daty", datyRepository.findAll());
        return "daty";


    }}


