package com.produkty.sklepbudowlany.tools;

import com.produkty.sklepbudowlany.model.Daty;
import com.produkty.sklepbudowlany.model.Dodatkowe;
import com.produkty.sklepbudowlany.model.Nazwa;
import com.produkty.sklepbudowlany.model.Produkt;
import com.produkty.sklepbudowlany.repositories.DatyRepository;
import com.produkty.sklepbudowlany.repositories.DodatkoweRepository;
import com.produkty.sklepbudowlany.repositories.NazwaRepository;
import com.produkty.sklepbudowlany.repositories.ProduktRepository;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

@Component
public class DBInflater implements ApplicationListener<ContextRefreshedEvent> {

    private ProduktRepository produktRepository;
    private NazwaRepository nazwaRepository;
    private DatyRepository datyRepository;
    private DodatkoweRepository dodatkoweRepository;

    public DBInflater(ProduktRepository produktRepository, NazwaRepository nazwaRepository, DatyRepository datyRepository, DodatkoweRepository dodatkoweRepository) {
        this.produktRepository = produktRepository;
        this.nazwaRepository = nazwaRepository;
        this.datyRepository = datyRepository;
        this.dodatkoweRepository = dodatkoweRepository;
    }

    @Override
    public void onApplicationEvent(ContextRefreshedEvent contextRefreshedEvent) {
        initData();

    }

    private void initData() {
        Produkt Pustak = new Produkt("Pustak");
        Nazwa Ytong = new Nazwa("Ytong");
        Daty Dokiedy = new Daty("21.11.2019", "22.11.2020");
        Dodatkowe inf = new Dodatkowe("budowa");

        Dokiedy.getDodatkowe().add(inf);
        inf.getDaty().add(Dokiedy);
        Ytong.setProdukt(Pustak);

        produktRepository.save(Pustak);
        nazwaRepository.save(Ytong);
        datyRepository.save(Dokiedy);
        dodatkoweRepository.save(inf);


        Produkt Cement = new Produkt("Cement");
        Nazwa Gorazdze = new Nazwa("Gorazdze");
        Daty Dokiedy1 = new Daty("12.10.2019", "24.12.2020");
        Dodatkowe inf1 = new Dodatkowe("zaprawy");

        Dokiedy1.getDodatkowe().add(inf1);
        inf1.getDaty().add(Dokiedy1);
        Gorazdze.setProdukt(Cement);

        produktRepository.save(Cement);
        nazwaRepository.save(Gorazdze);
        datyRepository.save(Dokiedy1);
        dodatkoweRepository.save(inf1);
    }
}


















