package com.produkty.sklepbudowlany.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import java.util.HashSet;
import java.util.Set;
@Entity
public class Dodatkowe {
    @Id
    @GeneratedValue
    private Long Id;
    private String Dodatkoweinformacje;
    @ManyToMany
    private Set<Daty> Daty=new HashSet<>();

    public Dodatkowe() {
    }

    public Dodatkowe(String dodatkoweinformacje) {
        Dodatkoweinformacje = dodatkoweinformacje;
    }

    public Dodatkowe(Long id, String dodatkoweinformacje, Set<com.produkty.sklepbudowlany.model.Daty> daty) {
        Id = id;
        Dodatkoweinformacje = dodatkoweinformacje;
        Daty = daty;
    }

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public String getDodatkoweinformacje() {
        return Dodatkoweinformacje;
    }

    public void setDodatkoweinformacje(String dodatkoweinformacje) {
        Dodatkoweinformacje = dodatkoweinformacje;
    }

    public Set<com.produkty.sklepbudowlany.model.Daty> getDaty() {
        return Daty;
    }

    public void setDaty(Set<com.produkty.sklepbudowlany.model.Daty> daty) {
        Daty = daty;
    }

    @Override
    public String toString() {
        return "Dodatkowe{" +
                "Id=" + Id +
                ", Dodatkoweinformacje='" + Dodatkoweinformacje + '\'' +
                ", Daty=" + Daty +
                '}';
    }
}
