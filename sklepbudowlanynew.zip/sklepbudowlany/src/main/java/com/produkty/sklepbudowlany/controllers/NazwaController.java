package com.produkty.sklepbudowlany.controllers;

import com.produkty.sklepbudowlany.repositories.NazwaRepository;
import com.produkty.sklepbudowlany.repositories.ProduktRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

    @Controller
    public class NazwaController {
    private NazwaRepository nazwaRepository;
    public NazwaController(NazwaRepository nazwaRepository) {
        this.nazwaRepository = nazwaRepository;
    }

    @RequestMapping("nazwa")
    public String getnazwa(Model model) {


        model.addAttribute("nazwa", nazwaRepository.findAll());
        return "nazwa";


    }

}
