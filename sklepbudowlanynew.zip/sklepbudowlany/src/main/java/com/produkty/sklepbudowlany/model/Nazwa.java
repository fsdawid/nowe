package com.produkty.sklepbudowlany.model;

import javax.persistence.*;

@Entity
public class Nazwa {
    @Id
    @GeneratedValue
    private Long Id;
    private String Nazwafabryczna;
    @ManyToOne
    private Produkt Produkt;

    public Nazwa() {
    }

    public Nazwa(String nazwafabryczna) {
        Nazwafabryczna = nazwafabryczna;

    }

    public Nazwa(Long id, String nazwafabryczna, com.produkty.sklepbudowlany.model.Produkt produkt) {
        Id = id;
        Nazwafabryczna = nazwafabryczna;
        Produkt = produkt;
    }

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public String getNazwafabryczna() {
        return Nazwafabryczna;
    }

    public void setNazwafabryczna(String nazwafabryczna) {
        Nazwafabryczna = nazwafabryczna;
    }

    public com.produkty.sklepbudowlany.model.Produkt getProdukt() {
        return Produkt;
    }

    public void setProdukt(com.produkty.sklepbudowlany.model.Produkt produkt) {
        Produkt = produkt;
    }

    @Override
    public String toString() {
        return "Nazwa{" +
                "Id=" + Id +
                ", Nazwafabryczna='" + Nazwafabryczna + '\'' +
                ", Produkt=" + Produkt +
                '}';
    }
}
