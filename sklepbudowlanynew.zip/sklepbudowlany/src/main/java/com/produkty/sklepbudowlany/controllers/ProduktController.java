package com.produkty.sklepbudowlany.controllers;

import com.produkty.sklepbudowlany.repositories.ProduktRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
    @Controller
public class ProduktController {
        private ProduktRepository produktRepository;

        public ProduktController(ProduktRepository produktRepository) {
            this.produktRepository = produktRepository;
        }

        @RequestMapping("produkt")
        public String getprodukt(Model model) {


            model.addAttribute("produkt", produktRepository.findAll());
            return "produkt";


        }
    }