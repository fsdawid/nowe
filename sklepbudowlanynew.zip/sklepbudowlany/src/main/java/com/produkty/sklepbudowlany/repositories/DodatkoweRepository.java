package com.produkty.sklepbudowlany.repositories;

import com.produkty.sklepbudowlany.model.Dodatkowe;
import org.springframework.data.repository.CrudRepository;

public interface DodatkoweRepository extends CrudRepository<Dodatkowe, Long> {
}
