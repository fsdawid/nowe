package com.produkty.sklepbudowlany.controllers;

import com.produkty.sklepbudowlany.repositories.DodatkoweRepository;
import com.produkty.sklepbudowlany.repositories.ProduktRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class DodatkoweController {
    private DodatkoweRepository dodatkoweRepository;
    public DodatkoweController(DodatkoweRepository dodatkoweRepository) {
        this.dodatkoweRepository = dodatkoweRepository;
    }

    @RequestMapping("dodatkowe")
    public String getdodatkowe(Model model) {


        model.addAttribute("dodatkowe", dodatkoweRepository.findAll());
        return "dodatkowe";


    }}


