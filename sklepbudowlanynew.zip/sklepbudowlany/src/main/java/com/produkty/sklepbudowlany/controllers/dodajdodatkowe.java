package com.produkty.sklepbudowlany.controllers;

import com.produkty.sklepbudowlany.model.Dodatkowe;
import com.produkty.sklepbudowlany.repositories.DodatkoweRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@Controller
public class dodajdodatkowe {

    private DodatkoweRepository dodatkoweRepository;


    public dodajdodatkowe(DodatkoweRepository dodatkoweRepository) {
        this.dodatkoweRepository = dodatkoweRepository;
    }



    @RequestMapping("dodajdodatkowe")
    public String showNewProductPage(Model model) {
        Dodatkowe dodatkowe = new Dodatkowe();
        model.addAttribute("dodajdodatkowe", dodatkowe);

        return "dodajdodatkowe";
    }
    @RequestMapping(value = "/save4", method = RequestMethod.POST)
    public String savedodatkowe(@ModelAttribute("dodatkowe") Dodatkowe dodatkowe    ) {
        dodatkoweRepository.save(dodatkowe);


        return "redirect:/dodatkowe";}



}