package com.produkty.sklepbudowlany.repositories;

import com.produkty.sklepbudowlany.model.Produkt;
import org.springframework.data.repository.CrudRepository;

public interface ProduktRepository extends CrudRepository<Produkt,Long> {
}
