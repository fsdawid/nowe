package com.produkty.sklepbudowlany.controllers;

import com.produkty.sklepbudowlany.model.Daty;
import com.produkty.sklepbudowlany.repositories.DatyRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class dodajdaty{

    private DatyRepository datyRepository;


    public dodajdaty(DatyRepository datyRepository) {
        this.datyRepository = datyRepository;
    }



    @RequestMapping("dodajdaty")
    public String showNewProductPage(Model model) {
        Daty daty = new Daty();
        model.addAttribute("dodajdaty", daty);

        return "dodajdaty";
    }
    @RequestMapping(value = "/save3", method = RequestMethod.POST)
    public String savedaty(@ModelAttribute("daty") Daty daty    ) {
        datyRepository.save(daty);


        return "redirect:/daty";}



}
