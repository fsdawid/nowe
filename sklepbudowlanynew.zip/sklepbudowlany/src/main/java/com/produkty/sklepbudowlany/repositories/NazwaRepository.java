package com.produkty.sklepbudowlany.repositories;

import com.produkty.sklepbudowlany.model.Nazwa;
import org.springframework.data.repository.CrudRepository;

public interface NazwaRepository extends CrudRepository<Nazwa,Long> {
}
